import express from "express";
import db from "../db.js";
const router = express.Router();
router.get("/", (req,res)=>{ const rows = db.prepare("SELECT * FROM recettes ORDER BY id DESC").all(); res.json(rows); });
router.post("/", (req,res)=>{ const nom = (req.body?.nom ?? null);\n  const temps_min = (req.body?.temps_min ?? null);\n  const cout_matiere = (req.body?.cout_matiere ?? null); db.prepare("INSERT INTO recettes (nom,temps_min,cout_matiere) VALUES (?,?,?)").run([nom,temps_min,cout_matiere]); res.json({ok:true}); });
export default router;
