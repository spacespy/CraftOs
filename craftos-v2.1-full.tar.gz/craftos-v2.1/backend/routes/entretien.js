import express from "express";
import db from "../db.js";
const router = express.Router();
router.get("/", (req,res)=>{ const rows = db.prepare("SELECT * FROM entretien ORDER BY id DESC").all(); res.json(rows); });
router.post("/", (req,res)=>{ const item = (req.body?.item ?? null);\n  const frequence_j = (req.body?.frequence_j ?? null);\n  const dernier = (req.body?.dernier ?? null); db.prepare("INSERT INTO entretien (item,frequence_j,dernier) VALUES (?,?,?)").run([item,frequence_j,dernier]); res.json({ok:true}); });
export default router;
