import express from "express";
import db from "../db.js";
const router = express.Router();
router.get("/", (req,res)=>{ const rows = db.prepare("SELECT * FROM interventions ORDER BY id DESC").all(); res.json(rows); });
router.post("/", (req,res)=>{ const machine_id = (req.body?.machine_id ?? null);\n  const titre = (req.body?.titre ?? null);\n  const description = (req.body?.description ?? null); db.prepare("INSERT INTO interventions (machine_id,titre,description) VALUES (?,?,?)").run([machine_id,titre,description]); res.json({ok:true}); });
export default router;
