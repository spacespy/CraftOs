import express from "express";
import db from "../db.js";
const router = express.Router();
router.get("/", (req,res)=>{ const rows = db.prepare("SELECT * FROM conformite ORDER BY id DESC").all(); res.json(rows); });
router.post("/", (req,res)=>{ const reference = (req.body?.reference ?? null);\n  const statut = (req.body?.statut ?? null); db.prepare("INSERT INTO conformite (reference,statut) VALUES (?,?)").run([reference,statut]); res.json({ok:true}); });
export default router;
