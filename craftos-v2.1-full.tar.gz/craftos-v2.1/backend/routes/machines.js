import express from "express";
import db from "../db.js";
const router = express.Router();
router.get("/", (req,res)=>{ const rows = db.prepare("SELECT * FROM machines ORDER BY id DESC").all(); res.json(rows); });
router.post("/", (req,res)=>{ const nom = (req.body?.nom ?? null);\n  const type = (req.body?.type ?? null);\n  const numero_serie = (req.body?.numero_serie ?? null); db.prepare("INSERT INTO machines (nom,type,numero_serie) VALUES (?,?,?)").run([nom,type,numero_serie]); res.json({ok:true}); });
export default router;
