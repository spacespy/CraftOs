import express from "express";
import db from "../db.js";
const router = express.Router();
router.get("/", (req,res)=>{ const rows = db.prepare("SELECT * FROM compta ORDER BY id DESC").all(); res.json(rows); });
router.post("/", (req,res)=>{ const libelle = (req.body?.libelle ?? null);\n  const debit = (req.body?.debit ?? null);\n  const credit = (req.body?.credit ?? null); db.prepare("INSERT INTO compta (libelle,debit,credit) VALUES (?,?,?)").run([libelle,debit,credit]); res.json({ok:true}); });
export default router;
