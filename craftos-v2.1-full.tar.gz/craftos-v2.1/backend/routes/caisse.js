import express from "express";
import db from "../db.js";
const router = express.Router();
router.get("/", (req,res)=>{ const rows = db.prepare("SELECT * FROM caisse ORDER BY id DESC").all(); res.json(rows); });
router.post("/", (req,res)=>{ const article = (req.body?.article ?? null);\n  const prix_ht = (req.body?.prix_ht ?? null);\n  const tva = (req.body?.tva ?? null);\n  const qte = (req.body?.qte ?? null); db.prepare("INSERT INTO caisse (article,prix_ht,tva,qte) VALUES (?,?,?,?)").run([article,prix_ht,tva,qte]); res.json({ok:true}); });
export default router;
