import express from "express";
import db from "../db.js";
const router = express.Router();
router.get("/", (req,res)=>{ const rows = db.prepare("SELECT * FROM flux ORDER BY id DESC").all(); res.json(rows); });
router.post("/", (req,res)=>{ const type = (req.body?.type ?? null);\n  const valeur = (req.body?.valeur ?? null);\n  const unite = (req.body?.unite ?? null); db.prepare("INSERT INTO flux (type,valeur,unite) VALUES (?,?,?)").run([type,valeur,unite]); res.json({ok:true}); });
export default router;
