import express from "express";
import db from "../db.js";
const router = express.Router();
router.get("/", (req,res)=>{ const rows = db.prepare("SELECT * FROM ame ORDER BY id DESC").all(); res.json(rows); });
router.post("/", (req,res)=>{ const note = (req.body?.note ?? null); db.prepare("INSERT INTO ame (note) VALUES (?)").run([note]); res.json({ok:true}); });
export default router;
