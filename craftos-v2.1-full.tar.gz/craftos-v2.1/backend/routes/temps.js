import express from "express";
import db from "../db.js";
const router = express.Router();
router.get("/", (req,res)=>{ const rows = db.prepare("SELECT * FROM temps ORDER BY id DESC").all(); res.json(rows); });
router.post("/", (req,res)=>{ const projet_id = (req.body?.projet_id ?? null);\n  const tache = (req.body?.tache ?? null);\n  const duree_min = (req.body?.duree_min ?? null); db.prepare("INSERT INTO temps (projet_id,tache,duree_min) VALUES (?,?,?)").run([projet_id,tache,duree_min]); res.json({ok:true}); });
export default router;
