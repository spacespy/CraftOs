import express from "express";
import db from "../db.js";
const router = express.Router();
router.get("/", (req,res)=>{ const rows = db.prepare("SELECT * FROM communaute ORDER BY id DESC").all(); res.json(rows); });
router.post("/", (req,res)=>{ const sujet = (req.body?.sujet ?? null);\n  const message = (req.body?.message ?? null); db.prepare("INSERT INTO communaute (sujet,message) VALUES (?,?)").run([sujet,message]); res.json({ok:true}); });
export default router;
