import express from "express";
import db from "../db.js";
const router = express.Router();
router.get("/", (req,res)=>{ const rows = db.prepare("SELECT * FROM sauvegardes ORDER BY id DESC").all(); res.json(rows); });
router.post("/", (req,res)=>{ const libelle = (req.body?.libelle ?? null);\n  const status = (req.body?.status ?? null); db.prepare("INSERT INTO sauvegardes (libelle,status) VALUES (?,?)").run([libelle,status]); res.json({ok:true}); });
export default router;
