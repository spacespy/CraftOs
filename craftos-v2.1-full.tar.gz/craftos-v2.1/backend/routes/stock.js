import express from "express";
import db from "../db.js";
const router = express.Router();
router.get("/", (req,res)=>{ const rows = db.prepare("SELECT * FROM stock ORDER BY id DESC").all(); res.json(rows); });
router.post("/", (req,res)=>{ const reference = (req.body?.reference ?? null);\n  const nom = (req.body?.nom ?? null);\n  const quantite = (req.body?.quantite ?? null);\n  const unite = (req.body?.unite ?? null); db.prepare("INSERT INTO stock (reference,nom,quantite,unite) VALUES (?,?,?,?)").run([reference,nom,quantite,unite]); res.json({ok:true}); });
export default router;
