import express from "express";
import db from "../db.js";
const router = express.Router();
router.get("/", (req,res)=>{ const rows = db.prepare("SELECT * FROM factures ORDER BY id DESC").all(); res.json(rows); });
router.post("/", (req,res)=>{ const client_id = (req.body?.client_id ?? null);\n  const titre = (req.body?.titre ?? null);\n  const montant_ht = (req.body?.montant_ht ?? null); db.prepare("INSERT INTO factures (client_id,titre,montant_ht) VALUES (?,?,?)").run([client_id,titre,montant_ht]); res.json({ok:true}); });
export default router;
