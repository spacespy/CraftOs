import express from "express";
import db from "../db.js";
const router = express.Router();
router.get("/", (req,res)=>{ const rows = db.prepare("SELECT * FROM clients ORDER BY id DESC").all(); res.json(rows); });
router.post("/", (req,res)=>{ const nom = (req.body?.nom ?? null);\n  const email = (req.body?.email ?? null);\n  const tel = (req.body?.tel ?? null); db.prepare("INSERT INTO clients (nom,email,tel) VALUES (?,?,?)").run([nom,email,tel]); res.json({ok:true}); });
export default router;
