import db from "../db.js";
const n = db.prepare("SELECT COUNT(*) AS n FROM clients").get().n;
if(n===0){
  const st = db.prepare("INSERT INTO clients (nom,email,tel) VALUES (?,?,?)");
  st.run("Atelier Bel-Tan","contact@bel-tan.example","06 11 22 33 44");
  st.run("Artisa’Yann","yann@artisa.example","06 55 44 33 22");
  console.log("🌿 Données démo clients injectées.");
}else{
  console.log("ℹ️ Démo déjà présente, rien à faire.");
}
process.exit(0);
