import React from "react";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import Navbar from "./components/Navbar.jsx";
import Dashboard from "./components/Dashboard.jsx";
import Clients from "./components/Clients.jsx";
import Factures from "./components/Factures.jsx";
import Recettes from "./components/Recettes.jsx";
import Stock from "./components/Stock.jsx";
import Machines from "./components/Machines.jsx";
import Interventions from "./components/Interventions.jsx";
import Temps from "./components/Temps.jsx";
import Caisse from "./components/Caisse.jsx";
import Compta from "./components/Compta.jsx";
import Flux from "./components/Flux.jsx";
import Sauvegarde from "./components/Sauvegarde.jsx";
import Communaute from "./components/Communaute.jsx";
import Conformite from "./components/Conformite.jsx";
import Entretien from "./components/Entretien.jsx";
import Ame from "./components/Ame.jsx";
import Harmonie from "./components/Harmonie.jsx";
import "./assets/zen-mousse.css";
export default function App(){
  return (<BrowserRouter><Navbar/><div className="container"><Routes>
          <Route path="/" element={{{k}}} />
          <Route path="/clients" element={{{k}}} />
          <Route path="/factures" element={{{k}}} />
          <Route path="/recettes" element={{{k}}} />
          <Route path="/stock" element={{{k}}} />
          <Route path="/machines" element={{{k}}} />
          <Route path="/interventions" element={{{k}}} />
          <Route path="/temps" element={{{k}}} />
          <Route path="/caisse" element={{{k}}} />
          <Route path="/compta" element={{{k}}} />
          <Route path="/flux" element={{{k}}} />
          <Route path="/sauvegarde" element={{{k}}} />
          <Route path="/communaute" element={{{k}}} />
          <Route path="/conformite" element={{{k}}} />
          <Route path="/entretien" element={{{k}}} />
          <Route path="/ame" element={{{k}}} />
          <Route path="/harmonie" element={{{k}}} />
        </Routes></div></BrowserRouter>);
}
