import React from "react";
import { NavLink } from "react-router-dom";
export default function Navbar(){
  return (<nav className="navbar"><NavLink to="/" end>Dashboard</NavLink>
      <NavLink to="/clients" end>Clients</NavLink>
      <NavLink to="/factures" end>Factures</NavLink>
      <NavLink to="/recettes" end>Recettes</NavLink>
      <NavLink to="/stock" end>Stock</NavLink>
      <NavLink to="/machines" end>Machines</NavLink>
      <NavLink to="/interventions" end>Interventions</NavLink>
      <NavLink to="/temps" end>Temps</NavLink>
      <NavLink to="/caisse" end>Caisse</NavLink>
      <NavLink to="/compta" end>Compta</NavLink>
      <NavLink to="/flux" end>Flux</NavLink>
      <NavLink to="/sauvegarde" end>Sauvegarde</NavLink>
      <NavLink to="/communaute" end>Communauté</NavLink>
      <NavLink to="/conformite" end>Conformité</NavLink>
      <NavLink to="/entretien" end>Entretien</NavLink>
      <NavLink to="/ame" end>Âme</NavLink>
      <NavLink to="/harmonie" end>Harmonie</NavLink></nav>);
}
