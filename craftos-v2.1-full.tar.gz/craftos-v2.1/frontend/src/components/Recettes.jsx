import React, {useState,useEffect} from "react";
export default function Recettes(){
  const [items,setItems]=useState([]);
  const [form,setForm]=useState({});
  const load=async()=>{ const r=await fetch("/api/recettes"); setItems(await r.json()); };
  const add=async(e)=>{ e.preventDefault(); await fetch("/api/recettes",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(form)}); setForm({}); load(); };
  useEffect(()=>{load();},[]);
  return(<div><h1>Recettes</h1><form onSubmit={add} className="form"><input placeholder="nom" value={form.nom||""} onChange={e=>setForm({...form, nom: e.target.value})} />
        <input placeholder="temps_min" value={form.temps_min||""} onChange={e=>setForm({...form, temps_min: e.target.value})} />
        <input placeholder="cout_matiere" value={form.cout_matiere||""} onChange={e=>setForm({...form, cout_matiere: e.target.value})} /><button>Ajouter</button></form><ul className="list">{items.map(it=><li key={it.id}>{it.nom} — {it.temps_min} — {it.cout_matiere}</li>)}</ul></div>);
}
