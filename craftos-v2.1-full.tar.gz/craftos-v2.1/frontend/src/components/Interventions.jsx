import React, {useState,useEffect} from "react";
export default function Interventions(){
  const [items,setItems]=useState([]);
  const [form,setForm]=useState({});
  const load=async()=>{ const r=await fetch("/api/interventions"); setItems(await r.json()); };
  const add=async(e)=>{ e.preventDefault(); await fetch("/api/interventions",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(form)}); setForm({}); load(); };
  useEffect(()=>{load();},[]);
  return(<div><h1>Interventions</h1><form onSubmit={add} className="form"><input placeholder="machine_id" value={form.machine_id||""} onChange={e=>setForm({...form, machine_id: e.target.value})} />
        <input placeholder="titre" value={form.titre||""} onChange={e=>setForm({...form, titre: e.target.value})} />
        <input placeholder="description" value={form.description||""} onChange={e=>setForm({...form, description: e.target.value})} /><button>Ajouter</button></form><ul className="list">{items.map(it=><li key={it.id}>{it.machine_id} — {it.titre} — {it.description}</li>)}</ul></div>);
}
