import React, {useState,useEffect} from "react";
export default function Compta(){
  const [items,setItems]=useState([]);
  const [form,setForm]=useState({});
  const load=async()=>{ const r=await fetch("/api/compta"); setItems(await r.json()); };
  const add=async(e)=>{ e.preventDefault(); await fetch("/api/compta",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(form)}); setForm({}); load(); };
  useEffect(()=>{load();},[]);
  return(<div><h1>Compta</h1><form onSubmit={add} className="form"><input placeholder="libelle" value={form.libelle||""} onChange={e=>setForm({...form, libelle: e.target.value})} />
        <input placeholder="debit" value={form.debit||""} onChange={e=>setForm({...form, debit: e.target.value})} />
        <input placeholder="credit" value={form.credit||""} onChange={e=>setForm({...form, credit: e.target.value})} /><button>Ajouter</button></form><ul className="list">{items.map(it=><li key={it.id}>{it.libelle} — {it.debit} — {it.credit}</li>)}</ul></div>);
}
