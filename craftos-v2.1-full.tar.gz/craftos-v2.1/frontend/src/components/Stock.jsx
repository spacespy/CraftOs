import React, {useState,useEffect} from "react";
export default function Stock(){
  const [items,setItems]=useState([]);
  const [form,setForm]=useState({});
  const load=async()=>{ const r=await fetch("/api/stock"); setItems(await r.json()); };
  const add=async(e)=>{ e.preventDefault(); await fetch("/api/stock",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(form)}); setForm({}); load(); };
  useEffect(()=>{load();},[]);
  return(<div><h1>Stock</h1><form onSubmit={add} className="form"><input placeholder="reference" value={form.reference||""} onChange={e=>setForm({...form, reference: e.target.value})} />
        <input placeholder="nom" value={form.nom||""} onChange={e=>setForm({...form, nom: e.target.value})} />
        <input placeholder="quantite" value={form.quantite||""} onChange={e=>setForm({...form, quantite: e.target.value})} />
        <input placeholder="unite" value={form.unite||""} onChange={e=>setForm({...form, unite: e.target.value})} /><button>Ajouter</button></form><ul className="list">{items.map(it=><li key={it.id}>{it.reference} — {it.nom} — {it.quantite} — {it.unite}</li>)}</ul></div>);
}
