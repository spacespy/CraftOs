import React, {useState,useEffect} from "react";
export default function Entretien(){
  const [items,setItems]=useState([]);
  const [form,setForm]=useState({});
  const load=async()=>{ const r=await fetch("/api/entretien"); setItems(await r.json()); };
  const add=async(e)=>{ e.preventDefault(); await fetch("/api/entretien",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(form)}); setForm({}); load(); };
  useEffect(()=>{load();},[]);
  return(<div><h1>Entretien</h1><form onSubmit={add} className="form"><input placeholder="item" value={form.item||""} onChange={e=>setForm({...form, item: e.target.value})} />
        <input placeholder="frequence_j" value={form.frequence_j||""} onChange={e=>setForm({...form, frequence_j: e.target.value})} />
        <input placeholder="dernier" value={form.dernier||""} onChange={e=>setForm({...form, dernier: e.target.value})} /><button>Ajouter</button></form><ul className="list">{items.map(it=><li key={it.id}>{it.item} — {it.frequence_j} — {it.dernier}</li>)}</ul></div>);
}
