import React, {useState,useEffect} from "react";
export default function Harmonie(){
  const [items,setItems]=useState([]);
  const [form,setForm]=useState({});
  const load=async()=>{ const r=await fetch("/api/harmonie"); setItems(await r.json()); };
  const add=async(e)=>{ e.preventDefault(); await fetch("/api/harmonie",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(form)}); setForm({}); load(); };
  useEffect(()=>{load();},[]);
  return(<div><h1>Harmonie</h1><form onSubmit={add} className="form"><input placeholder="theme" value={form.theme||""} onChange={e=>setForm({...form, theme: e.target.value})} /><button>Ajouter</button></form><ul className="list">{items.map(it=><li key={it.id}>{it.theme}</li>)}</ul></div>);
}
