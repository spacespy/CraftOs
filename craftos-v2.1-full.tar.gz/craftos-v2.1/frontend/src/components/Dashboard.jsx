import React from "react";
export default function Dashboard(){ return (<div><h1>🌿 Tableau de bord</h1><p>v2.1 — 17 modules actifs (placeholders CRUD).</p></div>); }
