import React, {useState,useEffect} from "react";
export default function Conformité(){
  const [items,setItems]=useState([]);
  const [form,setForm]=useState({});
  const load=async()=>{ const r=await fetch("/api/conformite"); setItems(await r.json()); };
  const add=async(e)=>{ e.preventDefault(); await fetch("/api/conformite",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(form)}); setForm({}); load(); };
  useEffect(()=>{load();},[]);
  return(<div><h1>Conformité</h1><form onSubmit={add} className="form"><input placeholder="reference" value={form.reference||""} onChange={e=>setForm({...form, reference: e.target.value})} />
        <input placeholder="statut" value={form.statut||""} onChange={e=>setForm({...form, statut: e.target.value})} /><button>Ajouter</button></form><ul className="list">{items.map(it=><li key={it.id}>{it.reference} — {it.statut}</li>)}</ul></div>);
}
