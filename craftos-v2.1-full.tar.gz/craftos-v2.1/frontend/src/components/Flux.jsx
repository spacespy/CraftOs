import React, {useState,useEffect} from "react";
export default function Flux(){
  const [items,setItems]=useState([]);
  const [form,setForm]=useState({});
  const load=async()=>{ const r=await fetch("/api/flux"); setItems(await r.json()); };
  const add=async(e)=>{ e.preventDefault(); await fetch("/api/flux",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(form)}); setForm({}); load(); };
  useEffect(()=>{load();},[]);
  return(<div><h1>Flux</h1><form onSubmit={add} className="form"><input placeholder="type" value={form.type||""} onChange={e=>setForm({...form, type: e.target.value})} />
        <input placeholder="valeur" value={form.valeur||""} onChange={e=>setForm({...form, valeur: e.target.value})} />
        <input placeholder="unite" value={form.unite||""} onChange={e=>setForm({...form, unite: e.target.value})} /><button>Ajouter</button></form><ul className="list">{items.map(it=><li key={it.id}>{it.type} — {it.valeur} — {it.unite}</li>)}</ul></div>);
}
