import React, {useState,useEffect} from "react";
export default function Sauvegarde(){
  const [items,setItems]=useState([]);
  const [form,setForm]=useState({});
  const load=async()=>{ const r=await fetch("/api/sauvegarde"); setItems(await r.json()); };
  const add=async(e)=>{ e.preventDefault(); await fetch("/api/sauvegarde",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(form)}); setForm({}); load(); };
  useEffect(()=>{load();},[]);
  return(<div><h1>Sauvegarde</h1><form onSubmit={add} className="form"><input placeholder="libelle" value={form.libelle||""} onChange={e=>setForm({...form, libelle: e.target.value})} />
        <input placeholder="status" value={form.status||""} onChange={e=>setForm({...form, status: e.target.value})} /><button>Ajouter</button></form><ul className="list">{items.map(it=><li key={it.id}>{it.libelle} — {it.status}</li>)}</ul></div>);
}
