import React, {useState,useEffect} from "react";
export default function Communauté(){
  const [items,setItems]=useState([]);
  const [form,setForm]=useState({});
  const load=async()=>{ const r=await fetch("/api/communaute"); setItems(await r.json()); };
  const add=async(e)=>{ e.preventDefault(); await fetch("/api/communaute",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(form)}); setForm({}); load(); };
  useEffect(()=>{load();},[]);
  return(<div><h1>Communauté</h1><form onSubmit={add} className="form"><input placeholder="sujet" value={form.sujet||""} onChange={e=>setForm({...form, sujet: e.target.value})} />
        <input placeholder="message" value={form.message||""} onChange={e=>setForm({...form, message: e.target.value})} /><button>Ajouter</button></form><ul className="list">{items.map(it=><li key={it.id}>{it.sujet} — {it.message}</li>)}</ul></div>);
}
