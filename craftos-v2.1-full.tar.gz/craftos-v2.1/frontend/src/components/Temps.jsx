import React, {useState,useEffect} from "react";
export default function Temps(){
  const [items,setItems]=useState([]);
  const [form,setForm]=useState({});
  const load=async()=>{ const r=await fetch("/api/temps"); setItems(await r.json()); };
  const add=async(e)=>{ e.preventDefault(); await fetch("/api/temps",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(form)}); setForm({}); load(); };
  useEffect(()=>{load();},[]);
  return(<div><h1>Temps</h1><form onSubmit={add} className="form"><input placeholder="projet_id" value={form.projet_id||""} onChange={e=>setForm({...form, projet_id: e.target.value})} />
        <input placeholder="tache" value={form.tache||""} onChange={e=>setForm({...form, tache: e.target.value})} />
        <input placeholder="duree_min" value={form.duree_min||""} onChange={e=>setForm({...form, duree_min: e.target.value})} /><button>Ajouter</button></form><ul className="list">{items.map(it=><li key={it.id}>{it.projet_id} — {it.tache} — {it.duree_min}</li>)}</ul></div>);
}
