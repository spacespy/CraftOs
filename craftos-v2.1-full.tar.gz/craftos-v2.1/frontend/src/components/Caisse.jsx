import React, {useState,useEffect} from "react";
export default function Caisse(){
  const [items,setItems]=useState([]);
  const [form,setForm]=useState({});
  const load=async()=>{ const r=await fetch("/api/caisse"); setItems(await r.json()); };
  const add=async(e)=>{ e.preventDefault(); await fetch("/api/caisse",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(form)}); setForm({}); load(); };
  useEffect(()=>{load();},[]);
  return(<div><h1>Caisse</h1><form onSubmit={add} className="form"><input placeholder="article" value={form.article||""} onChange={e=>setForm({...form, article: e.target.value})} />
        <input placeholder="prix_ht" value={form.prix_ht||""} onChange={e=>setForm({...form, prix_ht: e.target.value})} />
        <input placeholder="tva" value={form.tva||""} onChange={e=>setForm({...form, tva: e.target.value})} />
        <input placeholder="qte" value={form.qte||""} onChange={e=>setForm({...form, qte: e.target.value})} /><button>Ajouter</button></form><ul className="list">{items.map(it=><li key={it.id}>{it.article} — {it.prix_ht} — {it.tva} — {it.qte}</li>)}</ul></div>);
}
