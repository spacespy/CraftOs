import React, {useState,useEffect} from "react";
export default function Clients(){
  const [items,setItems]=useState([]);
  const [form,setForm]=useState({});
  const load=async()=>{ const r=await fetch("/api/clients"); setItems(await r.json()); };
  const add=async(e)=>{ e.preventDefault(); await fetch("/api/clients",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(form)}); setForm({}); load(); };
  useEffect(()=>{load();},[]);
  return(<div><h1>Clients</h1><form onSubmit={add} className="form"><input placeholder="nom" value={form.nom||""} onChange={e=>setForm({...form, nom: e.target.value})} />
        <input placeholder="email" value={form.email||""} onChange={e=>setForm({...form, email: e.target.value})} />
        <input placeholder="tel" value={form.tel||""} onChange={e=>setForm({...form, tel: e.target.value})} /><button>Ajouter</button></form><ul className="list">{items.map(it=><li key={it.id}>{it.nom} — {it.email} — {it.tel}</li>)}</ul></div>);
}
