import React, {useState,useEffect} from "react";
export default function Machines(){
  const [items,setItems]=useState([]);
  const [form,setForm]=useState({});
  const load=async()=>{ const r=await fetch("/api/machines"); setItems(await r.json()); };
  const add=async(e)=>{ e.preventDefault(); await fetch("/api/machines",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(form)}); setForm({}); load(); };
  useEffect(()=>{load();},[]);
  return(<div><h1>Machines</h1><form onSubmit={add} className="form"><input placeholder="nom" value={form.nom||""} onChange={e=>setForm({...form, nom: e.target.value})} />
        <input placeholder="type" value={form.type||""} onChange={e=>setForm({...form, type: e.target.value})} />
        <input placeholder="numero_serie" value={form.numero_serie||""} onChange={e=>setForm({...form, numero_serie: e.target.value})} /><button>Ajouter</button></form><ul className="list">{items.map(it=><li key={it.id}>{it.nom} — {it.type} — {it.numero_serie}</li>)}</ul></div>);
}
