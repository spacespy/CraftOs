import React, {useState,useEffect} from "react";
export default function Âme(){
  const [items,setItems]=useState([]);
  const [form,setForm]=useState({});
  const load=async()=>{ const r=await fetch("/api/ame"); setItems(await r.json()); };
  const add=async(e)=>{ e.preventDefault(); await fetch("/api/ame",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(form)}); setForm({}); load(); };
  useEffect(()=>{load();},[]);
  return(<div><h1>Âme</h1><form onSubmit={add} className="form"><input placeholder="note" value={form.note||""} onChange={e=>setForm({...form, note: e.target.value})} /><button>Ajouter</button></form><ul className="list">{items.map(it=><li key={it.id}>{it.note}</li>)}</ul></div>);
}
