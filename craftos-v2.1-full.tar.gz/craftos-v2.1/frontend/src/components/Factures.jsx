import React, {useState,useEffect} from "react";
export default function Factures(){
  const [items,setItems]=useState([]);
  const [form,setForm]=useState({});
  const load=async()=>{ const r=await fetch("/api/factures"); setItems(await r.json()); };
  const add=async(e)=>{ e.preventDefault(); await fetch("/api/factures",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(form)}); setForm({}); load(); };
  useEffect(()=>{load();},[]);
  return(<div><h1>Factures</h1><form onSubmit={add} className="form"><input placeholder="client_id" value={form.client_id||""} onChange={e=>setForm({...form, client_id: e.target.value})} />
        <input placeholder="titre" value={form.titre||""} onChange={e=>setForm({...form, titre: e.target.value})} />
        <input placeholder="montant_ht" value={form.montant_ht||""} onChange={e=>setForm({...form, montant_ht: e.target.value})} /><button>Ajouter</button></form><ul className="list">{items.map(it=><li key={it.id}>{it.client_id} — {it.titre} — {it.montant_ht}</li>)}</ul></div>);
}
